% Load MatConvNet
% Change the path to your installation of MatConvNet
mcnpath = '~/matconvnet';

run(fullfile(mcnpath, 'matlab', 'vl_setupnn'))

% -------------------------------------------------------------------------
% Load VGG-ImageNet, give an overview
% -------------------------------------------------------------------------

% Indicate the location of imagenet-vgg-verydeep-16.mat
% you need to download it first from http://www.vlfeat.org/matconvnet/pretrained/
net = load('data/imagenet-vgg-verydeep-16.mat') ;
vl_simplenn_display(net) ;

%% -------------------------------------------------------------------------
% Use the model to classify an image
% -------------------------------------------------------------------------

% obtain and preprocess an image
im = imread('piano.jpg') ;
im_ = single(im) ; % note: 255 range
im_ = imresize(im_, net.normalization.imageSize(1:2)) ;
im_ = im_ - net.normalization.averageImage ;

% run the CNN
layer = length(net.layers);   % pick layer
res = init_res(layer) ;       % initializate response structure
res(1).x = im_;               % load image in first layer
res = forwardto(net, layer, res) ; % Forward propagation to selected layer

% show the classification result
scores = squeeze(gather(res(layer+1).x)) ;
[bestScore, best] = max(scores) ;
figure(1) ; clf ; imagesc(im) ; axis image ;
title(sprintf('%s (%d), score %.3f',...
net.classes.description{best}, best, bestScore)) ;

% backwardfrom has similar usage: you should keep the same res structure
% and backpropagate from an extra dzdy argument specifying the jacobian
% with respect to the last layer activations.
